# Sign Language Detection > 2024-11-06 3:39pm
https://universe.roboflow.com/ankitprojecta/sign-language-detection-tfb93

Provided by a Roboflow user
License: MIT

